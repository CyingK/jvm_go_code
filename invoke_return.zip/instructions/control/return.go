package control

import (
	"fmt"
	"jvm_go_code/invoke_return/instructions/base"
	"jvm_go_code/invoke_return/rtda"
)

// void
type RETURN struct {
	base.NoOperandsInstruction
}

func (self *RETURN) Execute(frame *rtda.Frame) {
	fmt.Println("return: 当前方法的栈帧出栈")
	frame.Thread().PopFrame()
}

func (self *RETURN) String() string {
	return "{type：return; " + self.NoOperandsInstruction.String() + "}"
}

// reference
type ARETURN struct {
	base.NoOperandsInstruction
}

func (self *ARETURN) Execute(frame *rtda.Frame) {
	fmt.Println("areturn: 弹出当前栈帧, 获取调用者栈帧, 将当前栈帧操作数栈的引用推入调用者栈帧")
	thread := frame.Thread()
	currentFrame := thread.PopFrame()
	invokerFrame := thread.TopFrame()
	ref := currentFrame.OperandStack().PopRef()
	invokerFrame.OperandStack().PushRef(ref)
}

func (self *ARETURN) String() string {
	return "{type：areturn; " + self.NoOperandsInstruction.String() + "}"
}

// double
type DRETURN struct {
	base.NoOperandsInstruction
}

func (self *DRETURN) Execute(frame *rtda.Frame) {
	fmt.Println("dreturn: 弹出当前栈帧, 获取调用者栈帧, 将当前栈帧操作数栈的 double 值推入调用者栈帧")
	thread := frame.Thread()
	currentFrame := thread.PopFrame()
	invokerFrame := thread.TopFrame()
	value := currentFrame.OperandStack().PopDouble()
	invokerFrame.OperandStack().PushDouble(value)
}

func (self *DRETURN) String() string {
	return "{type：dreturn; " + self.NoOperandsInstruction.String() + "}"
}

// float
type FRETURN struct {
	base.NoOperandsInstruction
}

func (self *FRETURN) Execute(frame *rtda.Frame) {
	fmt.Println("freturn: 弹出当前栈帧, 获取调用者栈帧, 将当前栈帧操作数栈的 float 值推入调用者栈帧")
	thread := frame.Thread()
	currentFrame := thread.PopFrame()
	invokerFrame := thread.TopFrame()
	value := currentFrame.OperandStack().PopFloat()
	invokerFrame.OperandStack().PushFloat(value)
}

func (self *FRETURN) String() string {
	return "{type：freturn; " + self.NoOperandsInstruction.String() + "}"
}

// int
type IRETURN struct {
	base.NoOperandsInstruction
}

func (self *IRETURN) Execute(frame *rtda.Frame) {
	fmt.Println("ireturn: 弹出当前栈帧, 获取调用者栈帧, 将当前栈帧操作数栈的 int 值推入调用者栈帧")
	thread := frame.Thread()
	currentFrame := thread.PopFrame()
	invokerFrame := thread.TopFrame()
	value := currentFrame.OperandStack().PopInt()
	invokerFrame.OperandStack().PushInt(value)
}


func (self *IRETURN) String() string {
	return "{type：ireturn; " + self.NoOperandsInstruction.String() + "}"
}

// long
type LRETURN struct {
	base.NoOperandsInstruction
}

func (self *LRETURN) String() string {
	return "{type：return; " + self.NoOperandsInstruction.String() + "}"
}

func (self *LRETURN) Execute(frame *rtda.Frame) {
	fmt.Println("lreturn: 弹出当前栈帧, 获取调用者栈帧, 将当前栈帧操作数栈的 long 值推入调用者栈帧")
	thread := frame.Thread()
	currentFrame := thread.PopFrame()
	invokerFrame := thread.TopFrame()
	value := currentFrame.OperandStack().PopLong()
	invokerFrame.OperandStack().PushLong(value)
}

