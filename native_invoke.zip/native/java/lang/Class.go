package lang

import (
	"jvm_go_code/native_invoke/native"
	"jvm_go_code/native_invoke/rtda"
	"jvm_go_code/native_invoke/rtda/heap"
)

const JAVA_LANG_CLASS = "java/lang/Class"

func init() {
	native.Register(JAVA_LANG_CLASS, "getPrimitiveClass", "(Ljava/lang/String;)Ljava/lang/Class;", getPrimitiveClass)
	native.Register(JAVA_LANG_CLASS, "getName0", "()Ljava/lang/String;", getName0)
	native.Register(JAVA_LANG_CLASS, "desiredAssertionStatus0", "(Ljava/lang/Class;)Z", desiredAssertionStatus0)
}

// (Ljava/lang/Class;)Z
func desiredAssertionStatus0(frame *rtda.Frame) {
	frame.GetOperandStack().PushBoolean(false)
}

// 从局部变量表中拿到 this 引用, 这是一个类对象引用, 通过 GetExtra() 方法可以获得与之对应的
// Class 结构体指针. 然后拿到类名, 转成Java字符串并推入操作数栈顶
// ()Ljava/lang/String;
func getName0(frame *rtda.Frame) {
	this := frame.GetLocalVars().GetThis()
	class := this.GetExtra().(*heap.Class)
	name := class.GetJavaName()
	nameObject := heap.ToJavaString(class.GetClassLoader(), name)
	frame.GetOperandStack().PushRef(nameObject)
}

// 静态方法. 先从局部变量表中拿到类名, 这是个Java字符串, 需要把它转成Go字符串. 基本类型的类已经加
// 载到了方法区中, 直接调用类加载器的 LoadClass() 方法获取即可. 最后, 把类对象引用推入操作数栈顶
// (Ljava/lang/String;)Ljava/lang/Class;
func getPrimitiveClass(frame *rtda.Frame) {
	nameObject := frame.GetLocalVars().GetRef(0)
	name := heap.ToGoString(nameObject)
	classLoader := frame.GetMethod().GetClass().GetClassLoader()
	class := classLoader.LoadClass(name).GetJavaClass()
	frame.GetOperandStack().PushRef(class)
}

// ()Z
func isInterface(frame *rtda.Frame) {
	vars := frame.GetLocalVars()
	this := vars.GetThis()
	class := this.GetExtra().(*heap.Class)

	stack := frame.GetOperandStack()
	stack.PushBoolean(class.IsInterface())
}

// ()Z
func isPrimitive(frame *rtda.Frame) {
	vars := frame.GetLocalVars()
	this := vars.GetThis()
	class := this.GetExtra().(*heap.Class)

	stack := frame.GetOperandStack()
	stack.PushBoolean(class.IsPrimitive())
}
