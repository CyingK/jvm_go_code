package misc

import (
	"jvm_go_code/exception/instructions/base"
	"jvm_go_code/exception/native"
	"jvm_go_code/exception/rtda"
	"jvm_go_code/exception/rtda/heap"
)

func init() {
	native.Register("sun/misc/VM", "initialize", "()V", initialize)
}

func initialize(frame *rtda.Frame) {
	vmClass := frame.GetMethod().GetClass()
	savedProps := vmClass.GetRefVar("savedProps", "Ljava/util/Properties;")
	key := heap.ToJavaString(vmClass.GetClassLoader(), "foo")
	val := heap.ToJavaString(vmClass.GetClassLoader(), "bar")
	frame.GetOperandStack().PushRef(savedProps)
	frame.GetOperandStack().PushRef(key)
	frame.GetOperandStack().PushRef(val)
	propsClass := vmClass.GetClassLoader().LoadClass("java/util/Properties")
	setPropMethod := propsClass.GetInstanceMethod("setProperty",
		"(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;")
	base.InvokeMethod(frame, setPropMethod)
}