package heap

import "jvm_go_code/invoke_return/classfile"

type Method struct {
	ClassMember
	maxStack		uint
	maxLocals		uint
	code			[]byte
	argSlotCount	uint
}

func newMethods(class *Class, classFileMethod []*classfile.MemberInfo) []*Method {
	methods := make([]*Method, len(classFileMethod))
	for index, item := range classFileMethod {
		methods[index] = &Method{}
		methods[index].class = class
		methods[index].copyMemberInfo(item)
		methods[index].copyAttributes(item)
		methods[index].calcArgSlotCount()
	}
	return methods
}

func (self *Method) copyAttributes(classFileMethod *classfile.MemberInfo) {
	if codeAttr := classFileMethod.CodeAttribute(); codeAttr != nil {
		self.maxStack = codeAttr.MaxStack()
		self.maxLocals = codeAttr.MaxLocals()
		self.code = codeAttr.Code()
	}
}

func (self *Method) IsSynchronized() bool {
	return 0 != self.accessFlags&ACC_SYNCHRONIZED
}

func (self *Method) IsBridge() bool {
	return 0 != self.accessFlags&ACC_BRIDGE
}

func (self *Method) IsVarargs() bool {
	return 0 != self.accessFlags&ACC_VARARGS
}

func (self *Method) IsNative() bool {
	return 0 != self.accessFlags&ACC_NATIVE
}

func (self *Method) IsAbstract() bool {
	return 0 != self.accessFlags&ACC_ABSTRACT
}

func (self *Method) IsStrict() bool {
	return 0 != self.accessFlags&ACC_STRICT
}

func (self *Method) MaxLocals() uint {
	return self.maxLocals
}

func (self *Method) MaxStack() uint {
	return self.maxStack
}

func (self *Method) Code() []byte {
	return self.code
}

func (self *Method) ArgSlotCount() uint {
	return self.argSlotCount
}

// 计算局部变量表所需插槽数, 对每个参数都计一个插槽, Long 和 Double 类型要多占一个, 其次如果是非静态方法还要留一个给 this
func (self *Method) calcArgSlotCount() {
	parsedDescriptor := parseMethodDescriptor(self.descriptor)
	for _, item := range parsedDescriptor.parameterTypes {
		self.argSlotCount++
		if item == "J" || item == "D" {
			self.argSlotCount++
		}
	}
	if !self.IsStatic() {
		self.argSlotCount++
	}
}