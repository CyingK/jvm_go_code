package rtda

type Slot struct {
	num		int32		// 基本数据类型
	ref		*Object	// 引用数据类型
}
