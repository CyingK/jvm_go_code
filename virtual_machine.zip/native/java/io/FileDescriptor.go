package io

import (
	"jvm_go_code/Virtual_Machine/native"
	"jvm_go_code/Virtual_Machine/rtda"
)

const JAVA_IO_FILEDESCRIPTOR = "java/io/FileDescriptor"

func init() {
	native.Register(JAVA_IO_FILEDESCRIPTOR, "set", "(I)J", set)
}

func set(frame *rtda.Frame) {
	frame.GetOperandStack().PushLong(0)
}
