package atomic

import (
	"jvm_go_code/Virtual_Machine/native"
	"jvm_go_code/Virtual_Machine/rtda"
)

func init() {
	native.Register("java/util/concurrent/atomic/AtomicLong", "VMSupportsCS8", "()Z", vmSupportsCS8)
}

func vmSupportsCS8(frame *rtda.Frame) {
	frame.GetOperandStack().PushBoolean(false)
}
