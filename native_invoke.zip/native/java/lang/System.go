package lang

import (
	"jvm_go_code/native_invoke/native"
	"jvm_go_code/native_invoke/rtda"
	"jvm_go_code/native_invoke/rtda/heap"
)

const JAVA_LANG_SYSTEM = "java/lang/System"

func init() {
	native.Register(JAVA_LANG_SYSTEM, "arraycopy", "(Ljava/lang/Object;ILjava/lang/Object;II)V", arraycopy)
}

func arraycopy(frame *rtda.Frame) {
	vars := frame.GetLocalVars()
	src := vars.GetRef(0)
	srcPos := vars.GetInt(1)
	dest := vars.GetRef(2)
	destPos := vars.GetInt(3)
	length := vars.GetInt(4)
	// 源数组和目标数组都不能是 null
	if src == nil || dest == nil {
		panic("java.lang.NullPointerException")
	}
	// 源数组和目标数组必须兼容才能拷贝
	if !checkArrayCopy(src, dest) {
		panic("java.lang.ArrayStoreException")
	}
	// 检查srcPos, destPos和length参数
	if srcPos < 0 || destPos < 0 || length < 0 ||
		srcPos + length > src.GetArrayLength() ||
		destPos + length > dest.GetArrayLength() {
		panic("java.lang.IndexOutOfBoundsException")
	}
	heap.ArrayCopy(src, dest, srcPos, destPos, length)
}

// 首先确保 src 和 dest 都是数组, 然后检查数组类型. 如果两者都是引用数组, 则可以拷贝, 否则两者必须是
// 相同类型的基本类型数组
func checkArrayCopy(src *heap.Object, dest *heap.Object) bool {
	srcClass := src.GetClass()
	destClass := dest.GetClass()
	if !srcClass.IsArray() || !destClass.IsArray() {
		return false
	}
	if srcClass.GetComponentClass().IsPrimitive() ||
		destClass.GetComponentClass().IsPrimitive() {
		return srcClass == destClass
	}
	return true
}

