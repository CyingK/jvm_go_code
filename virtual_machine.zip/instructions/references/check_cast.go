package references

import (
	"fmt"
	"jvm_go_code/Virtual_Machine/instructions/base"
	"jvm_go_code/Virtual_Machine/rtda"
	"jvm_go_code/Virtual_Machine/rtda/heap"
)

type CHECK_CAST struct {
	base.Index16Instruction
}

func (self *CHECK_CAST) Execute(frame *rtda.Frame) {
	stack := frame.GetOperandStack()
	ref := stack.PopRef()
	stack.PushRef(ref)
	if ref == nil {
		fmt.Printf("check_cast: 此时引用为空\n")
		return
	}
	constantPool := frame.GetMethod().GetClass().GetConstantPool()
	classRef := constantPool.GetConstant(self.Index).(*heap.ClassRef)
	class := classRef.ResolvedClass()
	if !ref.IsInstanceOf(class) {
		panic("java.lang.ClassCastException")
	}
	fmt.Printf("check_cast: 确保 %v 能够转换为 %v\n", ref.GetClass().GetName(), class.GetName())
}

func (self *CHECK_CAST) String() string {
	return "{type：check_cast; " + self.Index16Instruction.String() + "}\t"
}