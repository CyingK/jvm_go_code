package main

import (
	"fmt"
	"jvm_go_code/invoke_return/instructions"
	"jvm_go_code/invoke_return/instructions/base"
	"jvm_go_code/invoke_return/rtda"
	"jvm_go_code/invoke_return/rtda/heap"
)

func interpret(method *heap.Method, logInstance bool) {
	thread := rtda.NewThread()
	frame := thread.NewFrame(method)
	thread.PushFrame(frame)

	defer catchErr(thread)
	loop(thread, logInstance)
}

func loop(thread *rtda.Thread, logInstance bool) {
	reader := &base.ByteCodeReader{}
	for {
		println()
		frame := thread.CurrentFrame()
		pc := frame.NextPC()
		thread.SetPC(pc)
		reader.Reset(frame.Method().Code(), pc)
		opCode := reader.ReadUint8()
		instance := instructions.NewInstruction(opCode)
		instance.FetchOperands(reader)
		frame.SetNextPC(reader.PC())
		if logInstance {
			logInstruction(frame, instance)
		}
		fmt.Printf("pc: %02d \ninstruction: [0x%02X]%v    ", pc, opCode, instance)
		instance.Execute(frame)
		if thread.IsStackEmpty() {
			break
		}
		catchErr(thread)
	}
}

func logInstruction(frame *rtda.Frame, instance base.Instructions) {
	method := frame.Method()
	className := method.Class().GetName()
	methodName := method.Name()
	pc := frame.Thread().PC()
	fmt.Printf("%v.%v() #%2d %T %v\n", className, methodName, pc, instance, instance)
}

func catchErr(thread *rtda.Thread) {
	if r := recover(); r != nil {
		logFrames(thread)
		panic(r)
	}
}

func logFrames(thread *rtda.Thread) {
	for !thread.IsStackEmpty() {
		frame := thread.PopFrame()
		method := frame.Method()
		className := method.Class().GetName()
		fmt.Printf(">> pc:%4d %v.%v%v \n", frame.NextPC(), className, method.Name(), method.Descriptor())
	}
}
