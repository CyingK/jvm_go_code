package heap

import (
	"jvm_go_code/native_invoke/classfile"
)

type Method struct {
	ClassMember
	maxStack		uint
	maxLocals		uint
	code			[]byte
	argSlotCount	uint
}

//--------------------------------------------------------------------构造器

func newMethods(class *Class, classFileMethods []*classfile.MemberInfo) []*Method {
	methods := make([]*Method, len(classFileMethods))
	for index, item := range classFileMethods {
		methods[index] = newMethod(class, item)
	}
	return methods
}

func newMethod(class *Class, classFileMethod *classfile.MemberInfo) *Method {
	method := &Method{}
	method.class = class
	method.copyMemberInfo(classFileMethod)
	method.copyAttributes(classFileMethod)
	methodDescriptor := parseMethodDescriptor(method.descriptor)
	method.calcArgSlotCount(methodDescriptor.parameterTypes)
	if method.IsNative() {
		method.injectCodeAttributes(methodDescriptor.returnType)
	}
	return method
}

//--------------------------------------------------------------------Getters

// 获取 maxLocals
func (self *Method) GetMaxLocals() uint {
	return self.maxLocals
}

// 获取 maxStack
func (self *Method) GetMaxStack() uint {
	return self.maxStack
}

// 获取 code
func (self *Method) GetCode() []byte {
	return self.code
}

// 获取 argSlotCount
func (self *Method) GetArgSlotCount() uint {
	return self.argSlotCount
}

//--------------------------------------------------------------------判断类方法

func (self *Method) IsSynchronized() bool {
	return 0 != self.accessFlags&ACC_SYNCHRONIZED
}

func (self *Method) IsBridge() bool {
	return 0 != self.accessFlags&ACC_BRIDGE
}

func (self *Method) IsVarargs() bool {
	return 0 != self.accessFlags&ACC_VARARGS
}

func (self *Method) IsNative() bool {
	return 0 != self.accessFlags&ACC_NATIVE
}

func (self *Method) IsAbstract() bool {
	return 0 != self.accessFlags&ACC_ABSTRACT
}

func (self *Method) IsStrict() bool {
	return 0 != self.accessFlags&ACC_STRICT
}

//--------------------------------------------------------------------功能类方法

// 计算局部变量表所需插槽数, 对每个参数都计一个插槽, Long 和 Double 类型要多占一个, 其次如果是非静态方法还要留一个给 this
func (self *Method) calcArgSlotCount(paramTypes []string) {
	//fmt.Printf("%v.%v:%v\n", self.GetClass().GetName(), self.GetName(), self.GetDescriptor())
	for _, item := range paramTypes {
		self.argSlotCount++
		if item == "J" || item == "D" {
			self.argSlotCount++
		}
	}
	if !self.IsStatic() {
		self.argSlotCount++
	}
}

// 复制属性
func (self *Method) copyAttributes(classFileMethod *classfile.MemberInfo) {
	if codeAttr := classFileMethod.GetCodeAttribute(); codeAttr != nil {
		self.maxStack = codeAttr.GetMaxStack()
		self.maxLocals = codeAttr.GetMaxLocals()
		self.code = codeAttr.GetCode()
	}
}

func (self *Method) injectCodeAttributes(returnType string) {
	self.maxStack = 4
	self.maxLocals = self.argSlotCount
	switch returnType[0] {
	case 'V':
		self.code = []byte{0xFE, 0xB1}
	case 'L', '[':
		self.code = []byte{0xFE, 0xB0}
	case 'D':
		self.code = []byte{0xFE, 0xAF}
	case 'F':
		self.code = []byte{0xFE, 0xAE}
	case 'J':
		self.code = []byte{0xFE, 0xAD}
	default:
		self.code = []byte{0xFE, 0xAC}
	}
}