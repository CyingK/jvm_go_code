package comparisons

// 引用的比较与跳转

/********************
 *    if_acmpeq		*
 *    if_acmpne		*
 ********************
 * 2				*
 ********************/

import (
	"fmt"
	"jvm_go_code/Virtual_Machine/instructions/base"
	"jvm_go_code/Virtual_Machine/rtda"
)

type IF_ACMPEQ struct {
	base.BranchInstruction
}

func (self *IF_ACMPEQ) Execute(frame *rtda.Frame) {
	stack := frame.GetOperandStack()
	ref2 := stack.PopRef()
	ref1 := stack.PopRef()
	if ref1 == ref2 {
		fmt.Printf("if_acmpeq: %v == %v = true, 程序计数器在原基础上做偏移: %v\n", &ref1, &ref2, self.Offset)
		base.Branch(frame, self.Offset)
	} else {
		fmt.Printf("if_acmpgt: %v == %v = false, 不进行操作\n", &ref1, &ref2)
	}
}

func (self *IF_ACMPEQ) String() string {
	return "{type：if_acmpeq; " + self.BranchInstruction.String() + "}\t"
}

type IF_ACMPNE struct {
	base.BranchInstruction
}

func (self *IF_ACMPNE) Execute(frame *rtda.Frame) {
	stack := frame.GetOperandStack()
	ref2 := stack.PopRef()
	ref1 := stack.PopRef()
	if ref1 != ref2 {
		fmt.Printf("if_acmpne: %v != %v = true, 程序计数器在原基础上做偏移: %v\n", &ref1, &ref2, self.Offset)
		base.Branch(frame, self.Offset)
	} else {
		fmt.Printf("if_acmpne: %v != %v = false, 不进行操作\n", &ref1, &ref2)
	}
}

func (self *IF_ACMPNE) String() string {
	return "{type：if_acmpne; " + self.BranchInstruction.String() + "}\t"
}