package references

import (
	"fmt"
	"jvm_go_code/Virtual_Machine/instructions/base"
	"jvm_go_code/Virtual_Machine/rtda"
)

type MONITOR_ENTER struct{ base.NoOperandsInstruction }

func (self *MONITOR_ENTER) Execute(frame *rtda.Frame) {
	ref := frame.GetOperandStack().PopRef()
	if ref == nil {
		panic("java.lang.NullPointerException")
	}
	fmt.Println("monitor_enter: 对象进入加锁状态")
}

func (self *MONITOR_ENTER) String() string {
	return "{type：monitor_enter; " + self.NoOperandsInstruction.String() + "}\t"
}

type MONITOR_EXIT struct{ base.NoOperandsInstruction }

func (self *MONITOR_EXIT) Execute(frame *rtda.Frame) {
	ref := frame.GetOperandStack().PopRef()
	if ref == nil {
		panic("java.lang.NullPointerException")
	}
	fmt.Println("monitor_exit: 对象退出加锁状态")
}

func (self *MONITOR_EXIT) String() string {
	return "{type：monitor_exit; " + self.NoOperandsInstruction.String() + "}\t"
}

