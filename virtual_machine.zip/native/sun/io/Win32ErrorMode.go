package io

import (
	"jvm_go_code/Virtual_Machine/native"
	"jvm_go_code/Virtual_Machine/rtda"
)

func init() {
	native.Register("sun/io/Win32ErrorMode", "setErrorMode", "(J)J", setErrorMode)
}

func setErrorMode(frame *rtda.Frame) {
	frame.GetOperandStack().PushLong(0)
}
