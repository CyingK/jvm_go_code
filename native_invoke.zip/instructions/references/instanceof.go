package references

import (
	"fmt"
	"jvm_go_code/native_invoke/instructions/base"
	"jvm_go_code/native_invoke/rtda"
	"jvm_go_code/native_invoke/rtda/heap"
)

type INSTANCE_OF struct {
	base.Index16Instruction
}

func (self *INSTANCE_OF) Execute(frame *rtda.Frame) {
	stack := frame.GetOperandStack()
	ref := stack.PopRef()
	if ref == nil {
		stack.PushInt(0)
		return
	}
	constantPool := frame.GetMethod().GetClass().GetConstantPool()
	classRef := constantPool.GetConstant(self.Index).(*heap.ClassRef)
	class := classRef.ResolvedClass()
	if ref.IsInstanceOf(class) {
		stack.PushInt(1)
		fmt.Printf("instance_of: %v 是 %v 类型\n", ref.GetClass().GetName(), class.GetName())
	} else {
		stack.PushInt(0)
		fmt.Printf("instance_of: %v 不是 %v 类型\n", ref.GetClass().GetName(), class.GetName())
	}
}

func (self *INSTANCE_OF) String() string {
	return "{type：instance_of; " + self.Index16Instruction.String() + "}"
}