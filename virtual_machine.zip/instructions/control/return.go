package control

import (
	"fmt"
	"jvm_go_code/Virtual_Machine/instructions/base"
	"jvm_go_code/Virtual_Machine/rtda"
)

// void
type RETURN struct {
	base.NoOperandsInstruction
}

func (self *RETURN) Execute(frame *rtda.Frame) {
	method := frame.GetMethod()
	fmt.Printf("return: 当前的栈帧(%v.%v:%v)出栈\n",
		method.GetClass().GetName(), method.GetName(), method.GetDescriptor())
	frame.GetThread().PopFrame()
}

func (self *RETURN) String() string {
	return "{type：return; " + self.NoOperandsInstruction.String() + "}\t"
}

// reference
type ARETURN struct {
	base.NoOperandsInstruction
}

func (self *ARETURN) Execute(frame *rtda.Frame) {
	thread := frame.GetThread()
	currentFrame := thread.PopFrame()
	invokerFrame := thread.GetTopFrame()
	ref := currentFrame.GetOperandStack().PopRef()
	invokerFrame.GetOperandStack().PushRef(ref)
	currentMethod := currentFrame.GetMethod()
	invokeMethod := invokerFrame.GetMethod()
	fmt.Printf("areturn: 弹出当前栈帧(%v.%v:%v), 将当前栈帧操作数栈的引用推入调用者栈帧(%v.%v:%v)\n",
		currentMethod.GetClass().GetName(), currentMethod.GetName(), currentMethod.GetDescriptor(),
		invokeMethod.GetClass().GetName(), invokeMethod.GetName(), invokeMethod.GetDescriptor())
}

func (self *ARETURN) String() string {
	return "{type：areturn; " + self.NoOperandsInstruction.String() + "}\t"
}

// double
type DRETURN struct {
	base.NoOperandsInstruction
}

func (self *DRETURN) Execute(frame *rtda.Frame) {
	thread := frame.GetThread()
	currentFrame := thread.PopFrame()
	invokerFrame := thread.GetTopFrame()
	value := currentFrame.GetOperandStack().PopDouble()
	invokerFrame.GetOperandStack().PushDouble(value)
	currentMethod := currentFrame.GetMethod()
	invokeMethod := invokerFrame.GetMethod()
	fmt.Printf("dreturn: 弹出当前栈帧(%v.%v:%v), 将当前栈帧操作数栈的值推入调用者栈帧(%v.%v:%v)\n",
		currentMethod.GetClass().GetName(), currentMethod.GetName(), currentMethod.GetDescriptor(),
		invokeMethod.GetClass().GetName(), invokeMethod.GetName(), invokeMethod.GetDescriptor())
}

func (self *DRETURN) String() string {
	return "{type：dreturn; " + self.NoOperandsInstruction.String() + "}\t"
}

// float
type FRETURN struct {
	base.NoOperandsInstruction
}

func (self *FRETURN) Execute(frame *rtda.Frame) {
	thread := frame.GetThread()
	currentFrame := thread.PopFrame()
	invokerFrame := thread.GetTopFrame()
	value := currentFrame.GetOperandStack().PopFloat()
	invokerFrame.GetOperandStack().PushFloat(value)
	currentMethod := currentFrame.GetMethod()
	invokeMethod := invokerFrame.GetMethod()
	fmt.Printf("freturn: 弹出当前栈帧(%v.%v:%v), 将当前栈帧操作数栈的值推入调用者栈帧(%v.%v:%v)\n",
		currentMethod.GetClass().GetName(), currentMethod.GetName(), currentMethod.GetDescriptor(),
		invokeMethod.GetClass().GetName(), invokeMethod.GetName(), invokeMethod.GetDescriptor())
}

func (self *FRETURN) String() string {
	return "{type：freturn; " + self.NoOperandsInstruction.String() + "}\t"
}

// int
type IRETURN struct {
	base.NoOperandsInstruction
}

func (self *IRETURN) Execute(frame *rtda.Frame) {
	thread := frame.GetThread()
	currentFrame := thread.PopFrame()
	invokerFrame := thread.GetTopFrame()
	value := currentFrame.GetOperandStack().PopInt()
	invokerFrame.GetOperandStack().PushInt(value)
	currentMethod := currentFrame.GetMethod()
	invokeMethod := invokerFrame.GetMethod()
	fmt.Printf("ireturn: 弹出当前栈帧(%v.%v:%v), 将当前栈帧操作数栈的值推入调用者栈帧(%v.%v:%v)\n",
		currentMethod.GetClass().GetName(), currentMethod.GetName(), currentMethod.GetDescriptor(),
		invokeMethod.GetClass().GetName(), invokeMethod.GetName(), invokeMethod.GetDescriptor())
}


func (self *IRETURN) String() string {
	return "{type：ireturn; " + self.NoOperandsInstruction.String() + "}\t"
}

// long
type LRETURN struct {
	base.NoOperandsInstruction
}

func (self *LRETURN) String() string {
	return "{type：return; " + self.NoOperandsInstruction.String() + "}\t"
}

func (self *LRETURN) Execute(frame *rtda.Frame) {
	thread := frame.GetThread()
	currentFrame := thread.PopFrame()
	invokerFrame := thread.GetTopFrame()
	value := currentFrame.GetOperandStack().PopLong()
	invokerFrame.GetOperandStack().PushLong(value)
	currentMethod := currentFrame.GetMethod()
	invokeMethod := invokerFrame.GetMethod()
	fmt.Printf("lreturn: 弹出当前栈帧(%v.%v:%v), 将当前栈帧操作数栈的值推入调用者栈帧(%v.%v:%v)\n",
		currentMethod.GetClass().GetName(), currentMethod.GetName(), currentMethod.GetDescriptor(),
		invokeMethod.GetClass().GetName(), invokeMethod.GetName(), invokeMethod.GetDescriptor())
}

