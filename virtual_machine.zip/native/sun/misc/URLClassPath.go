package misc

import (
	"jvm_go_code/Virtual_Machine/native"
	"jvm_go_code/Virtual_Machine/rtda"
)

func init() {
	native.Register("sun/misc/URLClassPath", "getLookupCacheURLs", "(Ljava/lang/ClassLoader;)[Ljava/net/URL;", getLookupCacheURLs)
}

func getLookupCacheURLs(frame *rtda.Frame) {
	frame.GetOperandStack().PushRef(nil)
}