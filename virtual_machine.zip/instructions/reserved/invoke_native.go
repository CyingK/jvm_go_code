package reserved

import (
	"fmt"
	"jvm_go_code/Virtual_Machine/instructions/base"
	"jvm_go_code/Virtual_Machine/native"
	_ "jvm_go_code/Virtual_Machine/native/java/io"
	_ "jvm_go_code/Virtual_Machine/native/java/lang"
	_ "jvm_go_code/Virtual_Machine/native/java/security"
	_ "jvm_go_code/Virtual_Machine/native/java/util/concurrent/atomic"
	_ "jvm_go_code/Virtual_Machine/native/sun/io"
	_ "jvm_go_code/Virtual_Machine/native/sun/misc"
	_ "jvm_go_code/Virtual_Machine/native/sun/reflect"
	"jvm_go_code/Virtual_Machine/rtda"
)

// 调用本地方法
type INVOKE_NATIVE struct {
	base.NoOperandsInstruction
}

// 分别取出获取本地方法所需的类名, 方法名, 方法描述, 然后去注册器里找对应方法, 若找到则调用
func (self *INVOKE_NATIVE) Execute(frame *rtda.Frame) {
	method := frame.GetMethod()
	className := method.GetClass().GetName()
	methodName := method.GetName()
	methodDescriptor := method.GetDescriptor()
	methodInfo := className + "." + methodName + ": " + methodDescriptor
	fmt.Println("invoke_native: 调用本地方法:", methodInfo)
	nativeMethod := native.FindNativeMethod(className, methodName, methodDescriptor)
	if nativeMethod == nil {
		panic("java.lang.UnsatisfiedLinkError: " + methodInfo)
	}
	nativeMethod(frame)
}

func (self *INVOKE_NATIVE) String() string {
	return "{type：invoke_native; " + self.NoOperandsInstruction.String() + "}\t"
}