package reserved

import (
	"fmt"
	"jvm_go_code/exception/instructions/base"
	"jvm_go_code/exception/native"
	_ "jvm_go_code/exception/native/java/lang"
	_ "jvm_go_code/exception/native/sun/misc"
	"jvm_go_code/exception/rtda"
)

// 调用本地方法
type INVOKE_NATIVE struct {
	base.NoOperandsInstruction
}

// 分别取出获取本地方法所需的类名, 方法名, 方法描述, 然后去注册器里找对应方法, 若找到则调用
func (self *INVOKE_NATIVE) Execute(frame *rtda.Frame) {
	method := frame.GetMethod()
	className := method.GetClass().GetName()
	methodName := method.GetName()
	methodDescriptor := method.GetDescriptor()
	nativeMethod := native.FindNativeMethod(className, methodName, methodDescriptor)
	methodInfo := className + "." + methodName + ": " + methodDescriptor
	if nativeMethod == nil {
		panic("java.lang.UnsatisfiedLinkError: " + methodInfo)
	}
	nativeMethod(frame)
	fmt.Println("invoke_native: 调用本地方法:", methodInfo)
}

func (self *INVOKE_NATIVE) String() string {
	return "{type：invoke_native; " + self.NoOperandsInstruction.String() + "}\t"
}