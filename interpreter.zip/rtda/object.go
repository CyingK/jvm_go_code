package rtda

type Object struct {

}

func (self *Object) String() string {
	return "nil"
}