package base

import "jvm_go_code/Virtual_Machine/rtda"

func Branch(frame *rtda.Frame, offset int) {
	pc := frame.GetThread().GetPC()
	nextPC := pc + offset
	frame.SetNextPC(nextPC)
}
