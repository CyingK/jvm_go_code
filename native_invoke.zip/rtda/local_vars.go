package rtda

import (
	"jvm_go_code/native_invoke/rtda/heap"
	"math"
)

type LocalVars []Slot

func newLocalVars(max uint) LocalVars {
	if max > 0 {
		return make([]Slot, max)
	}
	return nil
}

func (self LocalVars) SetInt(index uint, val int32) {
	self[index].num = val
}

func (self LocalVars) GetInt(index uint) int32 {
	return self[index].num
}

func (self LocalVars) SetFloat(index uint, val float32) {
	bits := math.Float32bits(val)
	self[index].num = int32(bits)
}

func (self LocalVars) GetFloat(index uint) float32 {
	bits := uint32(self[index].num)
	return math.Float32frombits(bits)
}

func (self LocalVars) SetLong(index uint, val int64) {
	self[index].num = int32(val)
	self[index + 1].num = int32(val >> 32)
}

func (self LocalVars) GetLong(index uint) int64 {
	low := uint32(self[index].num)
	high := uint32(self[index + 1].num)
	return int64(high) << 32 | int64(low)
}

func (self LocalVars) SetDouble(index uint, val float64) {
	bits := uint64(val)
	self.SetLong(index, int64(bits))
}

func (self LocalVars) GetDouble(index uint) float64 {
	bits := uint64(self.GetLong(index))
	return math.Float64frombits(bits)
}

func (self LocalVars) SetRef(index uint, ref *heap.Object) {
	self[index].ref = ref
}

func (self LocalVars) GetRef(index uint) *heap.Object {
	return self[index].ref
}

func (self LocalVars) GetSlot(index uint) Slot {
	return self[index]
}

func (self LocalVars) SetSlot(index uint, slot Slot) {
	self[index] = slot
}

func (self LocalVars) String() string {
	var result string
	for index, item := range self {
		result += item.String()
		if index != len(self) - 1 {
			result += ", "
		}
	}
	return result
}

func (self LocalVars) GetThis() *heap.Object {
	return self.GetRef(0)
}